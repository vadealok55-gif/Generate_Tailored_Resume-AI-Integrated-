from src.core.models.resume_model import Resume, ContactInfo

__all__ = ["Resume", "ContactInfo"]
