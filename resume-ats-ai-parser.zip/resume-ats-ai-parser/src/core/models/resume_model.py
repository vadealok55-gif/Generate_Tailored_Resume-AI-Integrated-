from dataclasses import dataclass, field
from typing import List, Optional, Dict, Any
from datetime import datetime

@dataclass
class ContactInfo:
    name: str
    email: str
    phone: Optional[str] = None
    linkedin: Optional[str] = None
    location: Optional[str] = None
    confidence: float = 1.0

@dataclass
class Experience:
    job_title: str
    company: str
    start_date: Optional[str] = None
    end_date: Optional[str] = None
    responsibilities: List[str] = field(default_factory=list)
    achievements: List[str] = field(default_factory=list)

@dataclass
class Education:
    degree: str
    institution: str
    graduation_date: Optional[str] = None

@dataclass
class Skill:
    name: str
    category: Optional[str] = None

@dataclass
class Resume:
    contact_info: ContactInfo
    professional_summary: Optional[str] = None
    experience: List[Experience] = field(default_factory=list)
    education: List[Education] = field(default_factory=list)
    skills: List[Skill] = field(default_factory=list)
    extraction_metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict:
        return {
            "contact_info": self.contact_info.__dict__,
            "professional_summary": self.professional_summary,
            "experience": [e.__dict__ for e in self.experience],
            "education": [e.__dict__ for e in self.education],
            "skills": [s.__dict__ for s in self.skills],
            "extraction_metadata": self.extraction_metadata
        }
